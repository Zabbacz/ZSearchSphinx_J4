# ZSearchSphinx_J4
Nejprve je treba nainstalovat sphinx - pouzita verze 3.3.1
postup instalace
https://drib.tech/programming/install-sphinx-3-fedora-30-thirty

Pripraveno na PHP 8.2
