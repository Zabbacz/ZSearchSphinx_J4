DROP TABLE IF EXISTS `#__zsphinx_recent_search`
